/*
# Seed Tourism Data

1. Overview
   Inserts 6 sample tourist destinations across India and 8 tour packages
   tied to those destinations. Uses the Pexels image URLs gathered for the project.
   Idempotent: uses ON CONFLICT DO NOTHING on a unique name constraint surrogate
   (checked via NOT EXISTS guards) so re-running is safe.

2. Destinations inserted
   - Goa, Kerala, Agra (Taj Mahal), Jaipur (Rajasthan), Manali (Himalayas), Ladakh

3. Packages inserted
   - 8 packages spanning the destinations with varied durations, prices, activities.
*/

INSERT INTO public.destinations (name, location, region, description, attractions, image_url)
SELECT 'Goa', 'Goa, India', 'West India',
  'Sun-kissed beaches, vibrant nightlife, and Portuguese heritage make Goa India''s favourite beach destination.',
  ARRAY['Baga Beach','Fort Aguada','Dudhsagar Falls','Old Goa Churches','Anjuna Flea Market'],
  'https://images.pexels.com/photos/28520254/pexels-photo-28520254.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE NOT EXISTS (SELECT 1 FROM public.destinations WHERE name = 'Goa');

INSERT INTO public.destinations (name, location, region, description, attractions, image_url)
SELECT 'Kerala', 'Kerala, India', 'South India',
  'God''s Own Country — serene backwaters, lush tea gardens, and traditional houseboats drifting through palm-fringed canals.',
  ARRAY['Alleppey Backwaters','Munnar Tea Gardens','Kathakali Performance','Periyar Wildlife Sanctuary','Kovalam Beach'],
  'https://images.pexels.com/photos/17928231/pexels-photo-17928231.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE NOT EXISTS (SELECT 1 FROM public.destinations WHERE name = 'Kerala');

INSERT INTO public.destinations (name, location, region, description, attractions, image_url)
SELECT 'Agra', 'Agra, Uttar Pradesh, India', 'North India',
  'Home to the iconic Taj Mahal, Agra is a timeless city of Mughal grandeur on the banks of the Yamuna.',
  ARRAY['Taj Mahal','Agra Fort','Fatehpur Sikri','Mehtab Bagh','Itimad-ud-Daulah'],
  'https://images.pexels.com/photos/11948442/pexels-photo-11948442.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE NOT EXISTS (SELECT 1 FROM public.destinations WHERE name = 'Agra');

INSERT INTO public.destinations (name, location, region, description, attractions, image_url)
SELECT 'Jaipur', 'Jaipur, Rajasthan, India', 'West India',
  'The Pink City — a regal blend of Rajput palaces, bustling bazaars, and desert forts painted in rose sandstone.',
  ARRAY['Amber Fort','Hawa Mahal','City Palace','Jantar Mantar','Nahargarh Fort'],
  'https://images.pexels.com/photos/32261804/pexels-photo-32261804.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE NOT EXISTS (SELECT 1 FROM public.destinations WHERE name = 'Jaipur');

INSERT INTO public.destinations (name, location, region, description, attractions, image_url)
SELECT 'Manali', 'Manali, Himachal Pradesh, India', 'North India',
  'A Himalayan hill station nestled in snow-capped peaks, gateway to adventure and alpine serenity.',
  ARRAY['Solang Valley','Rohtang Pass','Hadimba Temple','Old Manali','Beas River'],
  'https://images.pexels.com/photos/8020071/pexels-photo-8020071.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE NOT EXISTS (SELECT 1 FROM public.destinations WHERE name = 'Manali');

INSERT INTO public.destinations (name, location, region, description, attractions, image_url)
SELECT 'Ladakh', 'Leh, Ladakh, India', 'North India',
  'Land of high passes — stark mountain deserts, turquoise lakes, and ancient Buddhist monasteries.',
  ARRAY['Pangong Lake','Nubra Valley','Thiksey Monastery','Khardung La Pass','Shanti Stupa'],
  'https://images.pexels.com/photos/688576/pexels-photo-688576.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE NOT EXISTS (SELECT 1 FROM public.destinations WHERE name = 'Ladakh');

-- ============================================================
-- PACKAGES
-- ============================================================
DO $$
DECLARE
  goa_id uuid; kerala_id uuid; agra_id uuid; jaipur_id uuid; manali_id uuid; ladakh_id uuid;
BEGIN
  SELECT id INTO goa_id FROM public.destinations WHERE name = 'Goa';
  SELECT id INTO kerala_id FROM public.destinations WHERE name = 'Kerala';
  SELECT id INTO agra_id FROM public.destinations WHERE name = 'Agra';
  SELECT id INTO jaipur_id FROM public.destinations WHERE name = 'Jaipur';
  SELECT id INTO manali_id FROM public.destinations WHERE name = 'Manali';
  SELECT id INTO ladakh_id FROM public.destinations WHERE name = 'Ladakh';

  INSERT INTO public.packages (destination_id, title, description, duration_days, price, activities, inclusions, image_url, featured)
  SELECT goa_id, 'Goa Beach Bliss', 'A relaxed 4-day beach getaway with sunset cruises and water sports.', 4, 14999,
    ARRAY['Parasailing','Sunset Cruise','Beach Volleyball','Dolphon Spotting'],
    ARRAY['3-star beach resort','Daily breakfast','Airport transfers','Watersports session'],
    'https://images.pexels.com/photos/28159570/pexels-photo-28159570.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', true
  WHERE NOT EXISTS (SELECT 1 FROM public.packages WHERE title = 'Goa Beach Bliss');

  INSERT INTO public.packages (destination_id, title, description, duration_days, price, activities, inclusions, image_url, featured)
  SELECT kerala_id, 'Kerala Backwater Retreat', 'Drift through palm-fringed backwaters on a traditional houseboat for 5 serene days.', 5, 22999,
    ARRAY['Houseboat Stay','Ayurvedic Massage','Spice Plantation Tour','Kathakali Show'],
    ARRAY['Deluxe houseboat','All meals on boat','Ayurveda session','Sightseeing in AC vehicle'],
    'https://images.pexels.com/photos/32518360/pexels-photo-32518360.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', true
  WHERE NOT EXISTS (SELECT 1 FROM public.packages WHERE title = 'Kerala Backwater Retreat');

  INSERT INTO public.packages (destination_id, title, description, duration_days, price, activities, inclusions, image_url, featured)
  SELECT agra_id, 'Taj Mahal Heritage Tour', 'A 2-day immersive Mughal heritage experience around the Taj Mahal and Agra Fort.', 2, 7999,
    ARRAY['Sunrise Taj Visit','Agra Fort Tour','Marble Inlay Workshop','Mughal Cuisine Tasting'],
    ARRAY['4-star hotel','Breakfast','Monument tickets','English-speaking guide'],
    'https://images.pexels.com/photos/20476702/pexels-photo-20476702.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', true
  WHERE NOT EXISTS (SELECT 1 FROM public.packages WHERE title = 'Taj Mahal Heritage Tour');

  INSERT INTO public.packages (destination_id, title, description, duration_days, price, activities, inclusions, image_url, featured)
  SELECT jaipur_id, 'Royal Rajasthan Explorer', 'Discover the palaces and forts of the Pink City over 4 majestic days.', 4, 17999,
    ARRAY['Amber Fort Elephant Ride','Block Printing Workshop','Camel Safari','Rajasthani Thali Dinner'],
    ARRAY['Heritage haveli stay','Breakfast & dinner','All monument entry','Cultural show'],
    'https://images.pexels.com/photos/12323903/pexels-photo-12323903.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', true
  WHERE NOT EXISTS (SELECT 1 FROM public.packages WHERE title = 'Royal Rajasthan Explorer');

  INSERT INTO public.packages (destination_id, title, description, duration_days, price, activities, inclusions, image_url, featured)
  SELECT manali_id, 'Manali Snow Adventure', 'A 6-day Himalayan adventure with snow activities and mountain treks.', 6, 24999,
    ARRAY['Skiing at Solang','Paragliding','Snow Trekking','Bonfire Evening'],
    ARRAY['Mountain-view cottage','Breakfast & dinner','Adventure gear','Sightseeing transfers'],
    'https://images.pexels.com/photos/28689395/pexels-photo-28689395.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', false
  WHERE NOT EXISTS (SELECT 1 FROM public.packages WHERE title = 'Manali Snow Adventure');

  INSERT INTO public.packages (destination_id, title, description, duration_days, price, activities, inclusions, image_url, featured)
  SELECT manali_id, 'Manali Honeymoon Escape', 'A romantic 5-day retreat amid snowy peaks and pine forests.', 5, 27999,
    ARRAY['Couples Spa','Private Bonfire','Riverside Dinner','Rohtang Sightseeing'],
    ARRAY['Deluxe suite','Candlelight dinners','Spa session','Private transfers'],
    'https://images.pexels.com/photos/18359798/pexels-photo-18359798.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', false
  WHERE NOT EXISTS (SELECT 1 FROM public.packages WHERE title = 'Manali Honeymoon Escape');

  INSERT INTO public.packages (destination_id, title, description, duration_days, price, activities, inclusions, image_url, featured)
  SELECT ladakh_id, 'Ladakh Highland Expedition', 'An 8-day high-altitude expedition across monasteries and turquoise lakes.', 8, 39999,
    ARRAY['Pangong Lake Camping','Nubra Valley Drive','Monastery Tour','Stargazing Night'],
    ARRAY['Camp stays','All meals','AC SUV','Inner-line permits','Oxygen cylinder'],
    'https://images.pexels.com/photos/27593915/pexels-photo-27593915.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', true
  WHERE NOT EXISTS (SELECT 1 FROM public.packages WHERE title = 'Ladakh Highland Expedition');

  INSERT INTO public.packages (destination_id, title, description, duration_days, price, activities, inclusions, image_url, featured)
  SELECT goa_id, 'Goa Weekend Fling', 'A quick 3-day weekend escape to the beaches and shacks of North Goa.', 3, 9999,
    ARRAY['Beach Hopping','Casino Night','Flea Market','Catamaran Cruise'],
    ARRAY['Boutique resort','Breakfast','Casino entry','Airport pickup'],
    'https://images.pexels.com/photos/27869489/pexels-photo-27869489.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', false
  WHERE NOT EXISTS (SELECT 1 FROM public.packages WHERE title = 'Goa Weekend Fling');
END $$;
