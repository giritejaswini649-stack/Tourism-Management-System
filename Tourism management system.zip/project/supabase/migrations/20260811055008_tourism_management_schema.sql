/*
# Tourism Management System — Core Schema

1. Overview
   Full-stack tourism management system with user auth, destinations, tour packages,
   bookings, and reviews. Includes an admin role for managing content.

2. New Tables
   - profiles: extends auth.users with full_name, phone, role (user/admin). Auto-created on signup.
   - destinations: tourist destinations (name, location, region, description, attractions, image).
   - packages: tour packages tied to a destination (duration, price, activities, inclusions, featured).
   - bookings: a user's booking of a package (travel date, travelers, total, status).
   - reviews: user reviews/ratings for packages.

3. Helper Functions
   - is_admin(): SECURITY DEFINER, returns true if the current user's profile role is 'admin'.
   - handle_new_user(): trigger that creates a profile row on auth.users insert.
     The very first user to sign up becomes admin; subsequent users are 'user'.

4. Security (RLS)
   - profiles: users read/update own row; admins read all.
   - destinations: public read (anon+authenticated), admin-only write.
   - packages: public read, admin-only write.
   - bookings: users read/insert/update own; admins read all.
   - reviews: public read; authenticated insert own; owner or admin update/delete.
   All tables have RLS enabled. Admin write access gated by is_admin().
*/

-- ============================================================
-- TABLES (created before functions that reference them)
-- ============================================================
CREATE TABLE IF NOT EXISTS public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL DEFAULT '',
  phone text DEFAULT '',
  role text NOT NULL DEFAULT 'user' CHECK (role IN ('user','admin')),
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.destinations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  location text NOT NULL,
  region text NOT NULL DEFAULT '',
  description text NOT NULL DEFAULT '',
  attractions text[] NOT NULL DEFAULT '{}',
  image_url text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.packages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  destination_id uuid NOT NULL REFERENCES public.destinations(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text NOT NULL DEFAULT '',
  duration_days int NOT NULL DEFAULT 1 CHECK (duration_days > 0),
  price numeric(10,2) NOT NULL DEFAULT 0 CHECK (price >= 0),
  activities text[] NOT NULL DEFAULT '{}',
  inclusions text[] NOT NULL DEFAULT '{}',
  image_url text NOT NULL DEFAULT '',
  featured boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  package_id uuid NOT NULL REFERENCES public.packages(id) ON DELETE CASCADE,
  travel_date date NOT NULL,
  num_travelers int NOT NULL DEFAULT 1 CHECK (num_travelers > 0),
  total_price numeric(10,2) NOT NULL DEFAULT 0 CHECK (total_price >= 0),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','confirmed','cancelled')),
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  package_id uuid NOT NULL REFERENCES public.packages(id) ON DELETE CASCADE,
  rating int NOT NULL DEFAULT 5 CHECK (rating BETWEEN 1 AND 5),
  comment text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now()
);

-- ============================================================
-- HELPER FUNCTIONS
-- ============================================================
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
STABLE
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin'
  );
$$;

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  user_count int;
  assigned_role text;
BEGIN
  SELECT count(*) INTO user_count FROM public.profiles;
  assigned_role := CASE WHEN user_count = 0 THEN 'admin' ELSE 'user' END;
  INSERT INTO public.profiles (id, full_name, role)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name', ''), assigned_role);
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ============================================================
-- RLS ENABLE
-- ============================================================
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.destinations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.packages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;

-- ============================================================
-- POLICIES: PROFILES
-- ============================================================
DROP POLICY IF EXISTS "select_own_profile" ON public.profiles;
CREATE POLICY "select_own_profile" ON public.profiles
  FOR SELECT TO authenticated
  USING (auth.uid() = id OR public.is_admin());

DROP POLICY IF EXISTS "update_own_profile" ON public.profiles;
CREATE POLICY "update_own_profile" ON public.profiles
  FOR UPDATE TO authenticated
  USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- ============================================================
-- POLICIES: DESTINATIONS
-- ============================================================
DROP POLICY IF EXISTS "public_read_destinations" ON public.destinations;
CREATE POLICY "public_read_destinations" ON public.destinations
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "admin_insert_destinations" ON public.destinations;
CREATE POLICY "admin_insert_destinations" ON public.destinations
  FOR INSERT TO authenticated WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "admin_update_destinations" ON public.destinations;
CREATE POLICY "admin_update_destinations" ON public.destinations
  FOR UPDATE TO authenticated
  USING (public.is_admin()) WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "admin_delete_destinations" ON public.destinations;
CREATE POLICY "admin_delete_destinations" ON public.destinations
  FOR DELETE TO authenticated USING (public.is_admin());

-- ============================================================
-- POLICIES: PACKAGES
-- ============================================================
DROP POLICY IF EXISTS "public_read_packages" ON public.packages;
CREATE POLICY "public_read_packages" ON public.packages
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "admin_insert_packages" ON public.packages;
CREATE POLICY "admin_insert_packages" ON public.packages
  FOR INSERT TO authenticated WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "admin_update_packages" ON public.packages;
CREATE POLICY "admin_update_packages" ON public.packages
  FOR UPDATE TO authenticated
  USING (public.is_admin()) WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "admin_delete_packages" ON public.packages;
CREATE POLICY "admin_delete_packages" ON public.packages
  FOR DELETE TO authenticated USING (public.is_admin());

-- ============================================================
-- POLICIES: BOOKINGS
-- ============================================================
DROP POLICY IF EXISTS "select_own_bookings" ON public.bookings;
CREATE POLICY "select_own_bookings" ON public.bookings
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id OR public.is_admin());

DROP POLICY IF EXISTS "insert_own_bookings" ON public.bookings;
CREATE POLICY "insert_own_bookings" ON public.bookings
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_bookings" ON public.bookings;
CREATE POLICY "update_own_bookings" ON public.bookings
  FOR UPDATE TO authenticated
  USING (auth.uid() = user_id OR public.is_admin())
  WITH CHECK (auth.uid() = user_id OR public.is_admin());

DROP POLICY IF EXISTS "delete_own_bookings" ON public.bookings;
CREATE POLICY "delete_own_bookings" ON public.bookings
  FOR DELETE TO authenticated
  USING (auth.uid() = user_id OR public.is_admin());

-- ============================================================
-- POLICIES: REVIEWS
-- ============================================================
DROP POLICY IF EXISTS "public_read_reviews" ON public.reviews;
CREATE POLICY "public_read_reviews" ON public.reviews
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_own_reviews" ON public.reviews;
CREATE POLICY "insert_own_reviews" ON public.reviews
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_reviews" ON public.reviews;
CREATE POLICY "update_own_reviews" ON public.reviews
  FOR UPDATE TO authenticated
  USING (auth.uid() = user_id OR public.is_admin())
  WITH CHECK (auth.uid() = user_id OR public.is_admin());

DROP POLICY IF EXISTS "delete_own_reviews" ON public.reviews;
CREATE POLICY "delete_own_reviews" ON public.reviews
  FOR DELETE TO authenticated
  USING (auth.uid() = user_id OR public.is_admin());

-- ============================================================
-- INDEXES
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_packages_destination ON public.packages(destination_id);
CREATE INDEX IF NOT EXISTS idx_packages_featured ON public.packages(featured);
CREATE INDEX IF NOT EXISTS idx_bookings_user ON public.bookings(user_id);
CREATE INDEX IF NOT EXISTS idx_bookings_package ON public.bookings(package_id);
CREATE INDEX IF NOT EXISTS idx_reviews_package ON public.reviews(package_id);
