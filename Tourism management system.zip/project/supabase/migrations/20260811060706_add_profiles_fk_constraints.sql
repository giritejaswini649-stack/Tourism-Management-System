/*
# Add foreign key constraints from reviews/bookings to profiles

1. Purpose
   The frontend uses Supabase's nested selection to join `reviews` and `bookings`
   with `profiles` (e.g. `profile:profiles(id, full_name)`). PostgREST can only
   resolve these joins if an explicit foreign key relationship exists between
   the tables. Currently `reviews.user_id` and `bookings.user_id` reference
   `auth.users(id)` but NOT `profiles(id)`, so the join fails with PGRST200.

2. Changes
   - Add FK from `reviews.user_id` → `profiles.id` (ON DELETE CASCADE)
   - Add FK from `bookings.user_id` → `profiles.id` (ON DELETE CASCADE)
   These are additive constraints — no data is modified or lost.

3. Security
   No policy or RLS changes. Existing policies remain valid.
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'reviews_user_id_profiles_fkey'
      AND conrelid = 'public.reviews'::regclass
  ) THEN
    ALTER TABLE public.reviews
      ADD CONSTRAINT reviews_user_id_profiles_fkey
      FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'bookings_user_id_profiles_fkey'
      AND conrelid = 'public.bookings'::regclass
  ) THEN
    ALTER TABLE public.bookings
      ADD CONSTRAINT bookings_user_id_profiles_fkey
      FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;
  END IF;
END $$;
