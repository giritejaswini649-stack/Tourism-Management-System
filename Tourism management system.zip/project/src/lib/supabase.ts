import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
});

export type Profile = {
  id: string;
  full_name: string;
  phone: string;
  role: 'user' | 'admin';
  created_at: string;
};

export type Destination = {
  id: string;
  name: string;
  location: string;
  region: string;
  description: string;
  attractions: string[];
  image_url: string;
  created_at: string;
};

export type Package = {
  id: string;
  destination_id: string;
  title: string;
  description: string;
  duration_days: number;
  price: number;
  activities: string[];
  inclusions: string[];
  image_url: string;
  featured: boolean;
  created_at: string;
};

export type Booking = {
  id: string;
  user_id: string;
  package_id: string;
  travel_date: string;
  num_travelers: number;
  total_price: number;
  status: 'pending' | 'confirmed' | 'cancelled';
  created_at: string;
};

export type Review = {
  id: string;
  user_id: string;
  package_id: string;
  rating: number;
  comment: string;
  created_at: string;
};

export type PackageWithDestination = Package & {
  destination: Pick<Destination, 'id' | 'name' | 'location' | 'region'> | null;
};

export type BookingWithDetails = Booking & {
  package: Pick<Package, 'id' | 'title' | 'image_url' | 'duration_days'> | null;
};

export type ReviewWithProfile = Review & {
  profile: Pick<Profile, 'id' | 'full_name'> | null;
};
