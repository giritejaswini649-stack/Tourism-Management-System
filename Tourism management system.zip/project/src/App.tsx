import { AuthProvider } from '@/context/AuthContext';
import { RouterProvider, useRouter } from '@/context/RouterContext';
import { ToastProvider } from '@/context/ToastContext';
import { Navbar } from '@/components/layout/Navbar';
import { Footer } from '@/components/layout/Footer';
import { HomePage } from '@/pages/HomePage';
import { DestinationsPage } from '@/pages/DestinationsPage';
import { DestinationDetailPage } from '@/pages/DestinationDetailPage';
import { PackagesPage } from '@/pages/PackagesPage';
import { PackageDetailPage } from '@/pages/PackageDetailPage';
import { LoginPage } from '@/pages/LoginPage';
import { RegisterPage } from '@/pages/RegisterPage';
import { DashboardPage } from '@/pages/DashboardPage';
import { AdminPage } from '@/pages/AdminPage';
import { AboutPage } from '@/pages/AboutPage';

function Routes() {
  const { path } = useRouter();

  let page;
  if (path === '/' || path === '') page = <HomePage />;
  else if (path === '/destinations') page = <DestinationsPage />;
  else if (path.startsWith('/destinations/')) page = <DestinationDetailPage id={path.split('/')[2]} />;
  else if (path === '/packages') page = <PackagesPage />;
  else if (path.startsWith('/packages/')) page = <PackageDetailPage id={path.split('/')[2]} />;
  else if (path === '/login') page = <LoginPage />;
  else if (path === '/register') page = <RegisterPage />;
  else if (path === '/dashboard') page = <DashboardPage />;
  else if (path === '/admin') page = <AdminPage />;
  else if (path === '/about') page = <AboutPage />;
  else page = <HomePage />;

  const hideFooter = path === '/login' || path === '/register';

  return (
    <div className="flex min-h-screen flex-col bg-white">
      <Navbar />
      <main className="flex-1">{page}</main>
      {!hideFooter && <Footer />}
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <ToastProvider>
        <RouterProvider>
          <Routes />
        </RouterProvider>
      </ToastProvider>
    </AuthProvider>
  );
}

export default App;
