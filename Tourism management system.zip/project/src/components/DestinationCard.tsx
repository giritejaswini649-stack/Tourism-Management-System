import { MapPin } from 'lucide-react';
import type { Destination } from '@/lib/supabase';
import { Link } from '@/context/RouterContext';

export function DestinationCard({ destination }: { destination: Destination }) {
  return (
    <Link
      to={`/destinations/${destination.id}`}
      className="group relative block h-64 overflow-hidden rounded-2xl shadow-md transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-slate-900/15"
    >
      <img
        src={destination.image_url}
        alt={destination.name}
        className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
        loading="lazy"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-slate-900/85 via-slate-900/30 to-transparent" />
      <div className="absolute bottom-0 left-0 right-0 p-5">
        <div className="flex items-center gap-1.5 text-xs font-medium text-teal-300 mb-1">
          <MapPin className="h-3.5 w-3.5" />
          {destination.location}
        </div>
        <h3 className="text-xl font-bold text-white group-hover:text-teal-300 transition">
          {destination.name}
        </h3>
        <p className="mt-1 text-sm text-slate-200 line-clamp-1">
          {destination.attractions.slice(0, 3).join(' • ')}
        </p>
      </div>
    </Link>
  );
}
