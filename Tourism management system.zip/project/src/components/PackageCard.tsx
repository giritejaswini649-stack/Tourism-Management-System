import { MapPin, Clock, ArrowRight } from 'lucide-react';
import type { PackageWithDestination } from '@/lib/supabase';
import { Link } from '@/context/RouterContext';

export function PackageCard({ pkg }: { pkg: PackageWithDestination }) {
  const fmtPrice = new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(pkg.price);

  return (
    <Link
      to={`/packages/${pkg.id}`}
      className="group flex flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-slate-900/10 hover:border-teal-200"
    >
      <div className="relative h-52 overflow-hidden">
        <img
          src={pkg.image_url}
          alt={pkg.title}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
        />
        {pkg.featured && (
          <span className="absolute top-3 left-3 rounded-full bg-amber-400 px-3 py-1 text-xs font-semibold text-amber-950 shadow-sm">
            Featured
          </span>
        )}
        <div className="absolute bottom-3 right-3 rounded-full bg-white/95 px-3 py-1.5 text-sm font-bold text-teal-700 shadow-sm">
          {fmtPrice}
        </div>
      </div>
      <div className="flex flex-1 flex-col p-5">
        <div className="flex items-center gap-1.5 text-xs font-medium text-slate-400 mb-1.5">
          <MapPin className="h-3.5 w-3.5" />
          {pkg.destination?.name ?? 'India'}
        </div>
        <h3 className="text-base font-semibold text-slate-900 group-hover:text-teal-600 transition">
          {pkg.title}
        </h3>
        <p className="mt-1.5 text-sm leading-relaxed text-slate-500 line-clamp-2 flex-1">
          {pkg.description}
        </p>
        <div className="mt-4 flex items-center justify-between">
          <span className="inline-flex items-center gap-1.5 text-sm text-slate-600">
            <Clock className="h-4 w-4 text-slate-400" />
            {pkg.duration_days} days
          </span>
          <span className="inline-flex items-center gap-1 text-sm font-medium text-teal-600 group-hover:gap-2 transition-all">
            View Details <ArrowRight className="h-4 w-4" />
          </span>
        </div>
      </div>
    </Link>
  );
}
