import { Compass, Mail, Phone, MapPin } from 'lucide-react';
import { Link } from '@/context/RouterContext';

export function Footer() {
  return (
    <footer className="border-t border-slate-200 bg-slate-50">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-10 md:grid-cols-4">
          <div className="md:col-span-1">
            <div className="flex items-center gap-2.5">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-teal-500 to-cyan-600">
                <Compass className="h-5 w-5 text-white" />
              </div>
              <span className="text-lg font-bold text-slate-900">
                Wander<span className="text-teal-600">Way</span>
              </span>
            </div>
            <p className="mt-4 text-sm leading-relaxed text-slate-500">
              Your trusted partner for discovering incredible destinations across India.
              Plan, book, and explore with confidence.
            </p>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-slate-900">Explore</h4>
            <ul className="mt-4 space-y-2.5">
              <li><Link to="/destinations" className="text-sm text-slate-500 hover:text-teal-600 transition">Destinations</Link></li>
              <li><Link to="/packages" className="text-sm text-slate-500 hover:text-teal-600 transition">Tour Packages</Link></li>
              <li><Link to="/about" className="text-sm text-slate-500 hover:text-teal-600 transition">About Us</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-slate-900">Account</h4>
            <ul className="mt-4 space-y-2.5">
              <li><Link to="/login" className="text-sm text-slate-500 hover:text-teal-600 transition">Sign In</Link></li>
              <li><Link to="/register" className="text-sm text-slate-500 hover:text-teal-600 transition">Create Account</Link></li>
              <li><Link to="/dashboard" className="text-sm text-slate-500 hover:text-teal-600 transition">My Bookings</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-slate-900">Contact</h4>
            <ul className="mt-4 space-y-2.5">
              <li className="flex items-center gap-2 text-sm text-slate-500">
                <Mail className="h-4 w-4 text-teal-500" /> hello@wanderway.in
              </li>
              <li className="flex items-center gap-2 text-sm text-slate-500">
                <Phone className="h-4 w-4 text-teal-500" /> +91 98765 43210
              </li>
              <li className="flex items-center gap-2 text-sm text-slate-500">
                <MapPin className="h-4 w-4 text-teal-500" /> Latur, Maharashtra
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-10 border-t border-slate-200 pt-6">
          <p className="text-center text-sm text-slate-400">
            © 2026 WanderWay Tourism Management System. A college submission project.
          </p>
        </div>
      </div>
    </footer>
  );
}
