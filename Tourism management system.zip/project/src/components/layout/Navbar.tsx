import { useState } from 'react';
import { Compass, Menu, X, LogOut, LayoutDashboard, User, Shield } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { Link, useRouter } from '@/context/RouterContext';

export function Navbar() {
  const { user, profile, signOut } = useAuth();
  const { navigate } = useRouter();
  const [mobileOpen, setMobileOpen] = useState(false);

  const navLink = (to: string, label: string) => (
    <Link
      to={to}
      onClick={() => setMobileOpen(false)}
      className="text-sm font-medium text-slate-600 hover:text-teal-600 transition"
    >
      {label}
    </Link>
  );

  const handleSignOut = async () => {
    await signOut();
    setMobileOpen(false);
    navigate('/');
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-200/80 bg-white/80 backdrop-blur-lg">
      <nav className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link to="/" className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-teal-500 to-cyan-600 shadow-sm shadow-teal-500/30">
            <Compass className="h-5 w-5 text-white" />
          </div>
          <span className="text-lg font-bold tracking-tight text-slate-900">
            Wander<span className="text-teal-600">Way</span>
          </span>
        </Link>

        <div className="hidden items-center gap-8 md:flex">
          {navLink('/', 'Home')}
          {navLink('/destinations', 'Destinations')}
          {navLink('/packages', 'Packages')}
          {navLink('/about', 'About')}
        </div>

        <div className="hidden items-center gap-3 md:flex">
          {user ? (
            <>
              <Link
                to={profile?.role === 'admin' ? '/admin' : '/dashboard'}
                className="inline-flex items-center gap-1.5 text-sm font-medium text-slate-600 hover:text-teal-600 transition"
              >
                {profile?.role === 'admin' ? (
                  <Shield className="h-4 w-4" />
                ) : (
                  <LayoutDashboard className="h-4 w-4" />
                )}
                {profile?.role === 'admin' ? 'Admin' : 'Dashboard'}
              </Link>
              <button
                onClick={handleSignOut}
                className="inline-flex items-center gap-1.5 text-sm font-medium text-slate-600 hover:text-rose-600 transition"
              >
                <LogOut className="h-4 w-4" />
                Sign Out
              </button>
            </>
          ) : (
            <>
              <Link
                to="/login"
                className="text-sm font-medium text-slate-600 hover:text-teal-600 transition"
              >
                Sign In
              </Link>
              <Link
                to="/register"
                className="inline-flex items-center gap-1.5 rounded-xl bg-teal-600 px-4 py-2 text-sm font-medium text-white hover:bg-teal-700 transition shadow-sm shadow-teal-600/20"
              >
                <User className="h-4 w-4" />
                Get Started
              </Link>
            </>
          )}
        </div>

        <button
          className="md:hidden text-slate-700"
          onClick={() => setMobileOpen((v) => !v)}
        >
          {mobileOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </nav>

      {mobileOpen && (
        <div className="md:hidden border-t border-slate-100 bg-white px-4 py-4 space-y-3">
          {navLink('/', 'Home')}
          {navLink('/destinations', 'Destinations')}
          {navLink('/packages', 'Packages')}
          {navLink('/about', 'About')}
          <div className="pt-3 border-t border-slate-100 space-y-3">
            {user ? (
              <>
                <Link
                  to={profile?.role === 'admin' ? '/admin' : '/dashboard'}
                  onClick={() => setMobileOpen(false)}
                  className="block text-sm font-medium text-slate-600 hover:text-teal-600"
                >
                  {profile?.role === 'admin' ? 'Admin Panel' : 'My Dashboard'}
                </Link>
                <button
                  onClick={handleSignOut}
                  className="block text-sm font-medium text-slate-600 hover:text-rose-600"
                >
                  Sign Out
                </button>
              </>
            ) : (
              <>
                <Link
                  to="/login"
                  onClick={() => setMobileOpen(false)}
                  className="block text-sm font-medium text-slate-600 hover:text-teal-600"
                >
                  Sign In
                </Link>
                <Link
                  to="/register"
                  onClick={() => setMobileOpen(false)}
                  className="block text-sm font-medium text-teal-600"
                >
                  Get Started
                </Link>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
