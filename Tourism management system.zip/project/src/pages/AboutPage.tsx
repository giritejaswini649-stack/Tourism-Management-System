import { Compass, Target, Users, ShieldCheck, MapPin, TrendingUp } from 'lucide-react';
import { Link } from '@/context/RouterContext';
import { Button } from '@/components/ui/Button';

export function AboutPage() {
  return (
    <div>
      <section className="relative overflow-hidden bg-slate-900">
        <div className="absolute inset-0">
          <img
            src="https://images.pexels.com/photos/8020071/pexels-photo-8020071.jpeg?auto=compress&cs=tinysrgb&h=600&w=1400"
            alt="Himalayas"
            className="h-full w-full object-cover opacity-40"
          />
        </div>
        <div className="relative mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold tracking-tight text-white sm:text-5xl">About WanderWay</h1>
          <p className="mx-auto mt-4 max-w-2xl text-lg leading-relaxed text-slate-300">
            A Tourism Management System designed to simplify travel planning — connecting
            travellers with curated destinations and seamless booking experiences across India.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
          {[
            { icon: Target, title: 'Our Mission', desc: 'To digitize and simplify tourism management, making trip planning effortless for travellers and administrators alike.' },
            { icon: Users, title: 'For Everyone', desc: 'A platform built for both travellers exploring destinations and administrators managing the tourism ecosystem.' },
            { icon: ShieldCheck, title: 'Reliable & Secure', desc: 'Built with secure authentication and row-level security to protect user data and bookings at every step.' },
          ].map((f) => (
            <div key={f.title} className="rounded-2xl border border-slate-200 bg-white p-8">
              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-teal-50">
                <f.icon className="h-6 w-6 text-teal-600" />
              </div>
              <h3 className="text-lg font-semibold text-slate-900">{f.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-slate-500">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-slate-50 border-y border-slate-100">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold tracking-tight text-slate-900 text-center">What We Offer</h2>
          <div className="mt-10 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {[
              { icon: MapPin, title: 'Curated Destinations', desc: 'Explore handpicked tourist destinations with detailed information on attractions and highlights.' },
              { icon: Compass, title: 'Tour Packages', desc: 'Browse and book tour packages with transparent pricing, durations, and included activities.' },
              { icon: TrendingUp, title: 'Booking Management', desc: 'A structured system to book, track, and manage your travel plans all in one place.' },
            ].map((f) => (
              <div key={f.title} className="flex items-start gap-4 rounded-2xl bg-white p-6 border border-slate-200">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-teal-50">
                  <f.icon className="h-5 w-5 text-teal-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-slate-900">{f.title}</h3>
                  <p className="mt-1 text-sm leading-relaxed text-slate-500">{f.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="rounded-3xl bg-gradient-to-br from-teal-600 to-cyan-700 p-10 text-center sm:p-16">
          <h2 className="text-3xl font-bold text-white">Start Exploring Today</h2>
          <p className="mt-3 text-lg text-teal-100">Join WanderWay and discover your next adventure.</p>
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <Link to="/register">
              <Button size="lg" variant="secondary" className="bg-white text-teal-700 hover:bg-teal-50">Get Started</Button>
            </Link>
            <Link to="/destinations">
              <Button size="lg" variant="outline" className="border-white/40 text-white hover:bg-white/10">Browse Destinations</Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
