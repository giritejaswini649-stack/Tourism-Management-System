import { useEffect, useState } from 'react';
import { Search, SlidersHorizontal } from 'lucide-react';
import { supabase, type PackageWithDestination } from '@/lib/supabase';
import { PackageCard } from '@/components/PackageCard';
import { FullPageSpinner } from '@/components/ui/Spinner';

export function PackagesPage() {
  const [packages, setPackages] = useState<PackageWithDestination[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState<'featured' | 'price_low' | 'price_high' | 'duration'>('featured');

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from('packages')
        .select('*, destination:destinations(id, name, location, region)')
        .order('created_at', { ascending: false });
      setPackages(data ?? []);
      setLoading(false);
    })();
  }, []);

  if (loading) return <FullPageSpinner />;

  let filtered = packages.filter(
    (p) =>
      p.title.toLowerCase().includes(search.toLowerCase()) ||
      p.destination?.name?.toLowerCase().includes(search.toLowerCase())
  );

  filtered = [...filtered].sort((a, b) => {
    switch (sort) {
      case 'price_low': return a.price - b.price;
      case 'price_high': return b.price - a.price;
      case 'duration': return b.duration_days - a.duration_days;
      default: return Number(b.featured) - Number(a.featured);
    }
  });

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold tracking-tight text-slate-900">Tour Packages</h1>
        <p className="mt-2 text-lg text-slate-500">Find the perfect package for your next adventure</p>
      </div>

      <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3.5 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search packages..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full rounded-xl border border-slate-300 bg-white py-2.5 pl-11 pr-4 text-sm text-slate-700 placeholder-slate-400 focus:border-teal-500 focus:outline-none focus:ring-2 focus:ring-teal-500/20 transition"
          />
        </div>
        <div className="flex items-center gap-2">
          <SlidersHorizontal className="h-5 w-5 text-slate-400" />
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value as typeof sort)}
            className="rounded-xl border border-slate-300 bg-white py-2.5 pl-3 pr-8 text-sm text-slate-700 focus:border-teal-500 focus:outline-none focus:ring-2 focus:ring-teal-500/20 transition"
          >
            <option value="featured">Featured first</option>
            <option value="price_low">Price: Low to High</option>
            <option value="price_high">Price: High to Low</option>
            <option value="duration">Longest duration</option>
          </select>
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-12 text-center">
          <p className="text-slate-500">No packages found matching "{search}"</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filtered.map((p) => (
            <PackageCard key={p.id} pkg={p} />
          ))}
        </div>
      )}
    </div>
  );
}
