import { useEffect, useState } from 'react';
import { Clock, MapPin, CheckCircle, Users, Calendar, ArrowLeft, Star } from 'lucide-react';
import { supabase, type PackageWithDestination, type ReviewWithProfile } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { Link, useRouter } from '@/context/RouterContext';
import { Button } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';
import { StarRating } from '@/components/ui/StarRating';
import { useToast } from '@/context/ToastContext';
import { FullPageSpinner } from '@/components/ui/Spinner';

export function PackageDetailPage({ id }: { id: string }) {
  const { user } = useAuth();
  const { navigate } = useRouter();
  const { show } = useToast();
  const [pkg, setPkg] = useState<PackageWithDestination | null>(null);
  const [reviews, setReviews] = useState<ReviewWithProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [bookingOpen, setBookingOpen] = useState(false);
  const [travelDate, setTravelDate] = useState('');
  const [travelers, setTravelers] = useState(2);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    (async () => {
      const [{ data: pkgData }, { data: revData }] = await Promise.all([
        supabase
          .from('packages')
          .select('*, destination:destinations(id, name, location, region)')
          .eq('id', id)
          .maybeSingle(),
        supabase
          .from('reviews')
          .select('*, profile:profiles(id, full_name)')
          .eq('package_id', id)
          .order('created_at', { ascending: false }),
      ]);
      setPkg(pkgData as PackageWithDestination | null);
      setReviews(revData ?? []);
      setLoading(false);
    })();
  }, [id]);

  if (loading) return <FullPageSpinner />;

  if (!pkg) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-20 text-center">
        <h1 className="text-2xl font-bold text-slate-900">Package not found</h1>
        <Link to="/packages" className="mt-4 inline-block text-teal-600 hover:underline">Back to packages</Link>
      </div>
    );
  }

  const fmtPrice = new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(pkg.price);
  const totalPrice = pkg.price * travelers;
  const fmtTotal = new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(totalPrice);
  const avgRating = reviews.length > 0 ? reviews.reduce((s, r) => s + r.rating, 0) / reviews.length : 0;

  const handleBook = async () => {
    if (!user) {
      show('Please sign in to book a package.', 'info');
      navigate('/login');
      return;
    }
    if (!travelDate) {
      show('Please select a travel date.', 'error');
      return;
    }
    setSubmitting(true);
    const { error } = await supabase.from('bookings').insert({
      user_id: user.id,
      package_id: pkg.id,
      travel_date: travelDate,
      num_travelers: travelers,
      total_price: totalPrice,
      status: 'pending',
    });
    setSubmitting(false);
    if (error) {
      show('Booking failed: ' + error.message, 'error');
      return;
    }
    show('Booking confirmed! Check your dashboard for details.', 'success');
    setBookingOpen(false);
    navigate('/dashboard');
  };

  const today = new Date().toISOString().split('T')[0];

  return (
    <div>
      {/* Hero */}
      <div className="relative h-[45vh] min-h-[320px] overflow-hidden">
        <img src={pkg.image_url} alt={pkg.title} className="h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900/90 via-slate-900/50 to-slate-900/20" />
        <div className="absolute bottom-0 left-0 right-0 mx-auto max-w-7xl px-4 pb-8 sm:px-6 lg:px-8">
          <Link to="/packages" className="inline-flex items-center gap-1.5 text-sm text-white/80 hover:text-white transition mb-3">
            <ArrowLeft className="h-4 w-4" /> Back to packages
          </Link>
          <div className="flex items-center gap-2 text-teal-300 text-sm font-medium mb-2">
            <MapPin className="h-4 w-4" /> {pkg.destination?.name}, {pkg.destination?.location}
          </div>
          <h1 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">{pkg.title}</h1>
          <div className="mt-3 flex flex-wrap items-center gap-4 text-sm text-slate-200">
            <span className="inline-flex items-center gap-1.5"><Clock className="h-4 w-4" /> {pkg.duration_days} days</span>
            {reviews.length > 0 && (
              <span className="inline-flex items-center gap-1.5">
                <Star className="h-4 w-4 fill-amber-400 text-amber-400" /> {avgRating.toFixed(1)} ({reviews.length} reviews)
              </span>
            )}
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-10 lg:grid-cols-3">
          {/* Main */}
          <div className="lg:col-span-2 space-y-10">
            <div>
              <h2 className="text-2xl font-bold text-slate-900">Overview</h2>
              <p className="mt-4 text-base leading-relaxed text-slate-600">{pkg.description}</p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-slate-900">Activities</h2>
              <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
                {pkg.activities.map((a) => (
                  <div key={a} className="flex items-start gap-2.5 rounded-xl border border-slate-200 bg-white p-4">
                    <CheckCircle className="h-5 w-5 shrink-0 text-teal-500" />
                    <span className="text-sm text-slate-700">{a}</span>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-slate-900">What's Included</h2>
              <ul className="mt-4 space-y-3">
                {pkg.inclusions.map((inc) => (
                  <li key={inc} className="flex items-start gap-2.5 text-sm text-slate-600">
                    <CheckCircle className="h-5 w-5 shrink-0 text-teal-500" /> {inc}
                  </li>
                ))}
              </ul>
            </div>

            {/* Reviews */}
            <div>
              <h2 className="text-2xl font-bold text-slate-900">Reviews ({reviews.length})</h2>
              {reviews.length === 0 ? (
                <div className="mt-4 rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-8 text-center">
                  <Star className="mx-auto h-8 w-8 text-slate-300" />
                  <p className="mt-2 text-slate-500">No reviews yet. Book this package and be the first to review!</p>
                </div>
              ) : (
                <div className="mt-4 space-y-4">
                  {reviews.map((r) => (
                    <div key={r.id} className="rounded-2xl border border-slate-200 bg-white p-5">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-teal-100 text-sm font-semibold text-teal-700">
                            {(r.profile?.full_name ?? 'A')[0].toUpperCase()}
                          </div>
                          <div>
                            <p className="text-sm font-semibold text-slate-900">{r.profile?.full_name ?? 'Anonymous'}</p>
                            <p className="text-xs text-slate-400">{new Date(r.created_at).toLocaleDateString('en-IN')}</p>
                          </div>
                        </div>
                        <StarRating rating={r.rating} />
                      </div>
                      <p className="mt-3 text-sm leading-relaxed text-slate-600">{r.comment}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Sidebar booking card */}
          <div className="lg:col-span-1">
            <div className="sticky top-20 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
              <div className="text-3xl font-bold text-slate-900">{fmtPrice}</div>
              <p className="text-sm text-slate-500">per person</p>

              <div className="mt-5 space-y-3 border-t border-slate-100 pt-5">
                <div className="flex items-center gap-2 text-sm text-slate-600">
                  <Clock className="h-4 w-4 text-slate-400" /> {pkg.duration_days} days tour
                </div>
                <div className="flex items-center gap-2 text-sm text-slate-600">
                  <MapPin className="h-4 w-4 text-slate-400" /> {pkg.destination?.name}
                </div>
                <div className="flex items-center gap-2 text-sm text-slate-600">
                  <Users className="h-4 w-4 text-slate-400" /> Group size 1-10
                </div>
              </div>

              <Button className="mt-6 w-full" size="lg" onClick={() => setBookingOpen(true)}>
                Book Now
              </Button>
              <p className="mt-3 text-center text-xs text-slate-400">Free cancellation up to 7 days before</p>
            </div>
          </div>
        </div>
      </div>

      {/* Booking Modal */}
      <Modal open={bookingOpen} onClose={() => setBookingOpen(false)} title="Book This Package">
        <div className="space-y-5">
          <div className="rounded-xl bg-slate-50 p-4">
            <p className="font-semibold text-slate-900">{pkg.title}</p>
            <p className="text-sm text-slate-500">{pkg.destination?.name} • {pkg.duration_days} days</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Travel Date</label>
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
              <input
                type="date"
                min={today}
                value={travelDate}
                onChange={(e) => setTravelDate(e.target.value)}
                className="w-full rounded-xl border border-slate-300 bg-white py-2.5 pl-11 pr-4 text-sm text-slate-700 focus:border-teal-500 focus:outline-none focus:ring-2 focus:ring-teal-500/20 transition"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Number of Travellers</label>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setTravelers((v) => Math.max(1, v - 1))}
                className="flex h-10 w-10 items-center justify-center rounded-lg border border-slate-300 text-slate-600 hover:bg-slate-50 transition"
              >
                −
              </button>
              <span className="w-12 text-center text-lg font-semibold text-slate-900">{travelers}</span>
              <button
                onClick={() => setTravelers((v) => Math.min(10, v + 1))}
                className="flex h-10 w-10 items-center justify-center rounded-lg border border-slate-300 text-slate-600 hover:bg-slate-50 transition"
              >
                +
              </button>
            </div>
          </div>

          <div className="rounded-xl border border-slate-200 p-4 space-y-2">
            <div className="flex justify-between text-sm text-slate-600">
              <span>Package price × {travelers}</span>
              <span>{fmtTotal}</span>
            </div>
            <div className="flex justify-between border-t border-slate-100 pt-2 font-semibold text-slate-900">
              <span>Total</span>
              <span>{fmtTotal}</span>
            </div>
          </div>

          <Button className="w-full" size="lg" onClick={handleBook} disabled={submitting}>
            {submitting ? 'Confirming...' : 'Confirm Booking'}
          </Button>
        </div>
      </Modal>
    </div>
  );
}
