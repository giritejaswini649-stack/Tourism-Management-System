import { useEffect, useState } from 'react';
import { ArrowRight, MapPin, Compass, ShieldCheck, Headphones, Star } from 'lucide-react';
import { supabase, type PackageWithDestination, type Destination, type ReviewWithProfile } from '@/lib/supabase';
import { Link } from '@/context/RouterContext';
import { Button } from '@/components/ui/Button';
import { PackageCard } from '@/components/PackageCard';
import { DestinationCard } from '@/components/DestinationCard';
import { StarRating } from '@/components/ui/StarRating';
import { FullPageSpinner } from '@/components/ui/Spinner';

export function HomePage() {
  const [destinations, setDestinations] = useState<Destination[]>([]);
  const [packages, setPackages] = useState<PackageWithDestination[]>([]);
  const [reviews, setReviews] = useState<ReviewWithProfile[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const [{ data: destData }, { data: pkgData }, { data: revData }] = await Promise.all([
        supabase.from('destinations').select('*').limit(6),
        supabase
          .from('packages')
          .select('*, destination:destinations(id, name, location, region)')
          .eq('featured', true)
          .limit(4),
        supabase
          .from('reviews')
          .select('*, profile:profiles(id, full_name)')
          .order('created_at', { ascending: false })
          .limit(3),
      ]);
      setDestinations(destData ?? []);
      setPackages(pkgData ?? []);
      setReviews(revData ?? []);
      setLoading(false);
    })();
  }, []);

  if (loading) return <FullPageSpinner />;

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.pexels.com/photos/18563694/pexels-photo-18563694.jpeg?auto=compress&cs=tinysrgb&h=900&w=1400"
            alt="Himalayan landscape"
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-slate-900/90 via-slate-900/70 to-slate-900/40" />
        </div>
        <div className="relative mx-auto max-w-7xl px-4 py-24 sm:px-6 lg:px-8 lg:py-32">
          <div className="max-w-2xl">
            <span className="inline-flex items-center gap-2 rounded-full border border-teal-400/30 bg-teal-500/10 px-4 py-1.5 text-sm font-medium text-teal-300">
              <Compass className="h-4 w-4" /> Explore Incredible India
            </span>
            <h1 className="mt-6 text-4xl font-bold leading-tight tracking-tight text-white sm:text-5xl lg:text-6xl">
              Discover Your Next <span className="text-teal-400">Adventure</span>
            </h1>
            <p className="mt-5 text-lg leading-relaxed text-slate-200">
              From the snow-capped Himalayas to the sun-drenched beaches of Goa,
              find and book curated tour packages across India's most breathtaking destinations.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Link to="/packages">
                <Button size="lg">
                  Browse Packages <ArrowRight className="h-5 w-5" />
                </Button>
              </Link>
              <Link to="/destinations">
                <Button size="lg" variant="outline" className="bg-white/10 text-white border-white/30 hover:bg-white/20">
                  Explore Destinations
                </Button>
              </Link>
            </div>
            <div className="mt-10 flex items-center gap-6 text-sm text-slate-300">
              <div>
                <span className="text-2xl font-bold text-white">{destinations.length}+</span>
                <p className="text-xs text-slate-400">Destinations</p>
              </div>
              <div className="h-10 w-px bg-white/20" />
              <div>
                <span className="text-2xl font-bold text-white">{packages.length * 2}+</span>
                <p className="text-xs text-slate-400">Tour Packages</p>
              </div>
              <div className="h-10 w-px bg-white/20" />
              <div>
                <span className="text-2xl font-bold text-white">100%</span>
                <p className="text-xs text-slate-400">Secure Booking</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="border-b border-slate-100 bg-white">
        <div className="mx-auto grid max-w-7xl grid-cols-1 gap-8 px-4 py-12 sm:px-6 md:grid-cols-3 lg:px-8">
          {[
            { icon: ShieldCheck, title: 'Secure Booking', desc: 'Your bookings and payments are protected with bank-grade security.' },
            { icon: Compass, title: 'Curated Destinations', desc: 'Handpicked destinations and packages by experienced travel experts.' },
            { icon: Headphones, title: '24/7 Support', desc: 'Round-the-clock customer support for a worry-free travel experience.' },
          ].map((f) => (
            <div key={f.title} className="flex items-start gap-4">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-teal-50">
                <f.icon className="h-6 w-6 text-teal-600" />
              </div>
              <div>
                <h3 className="font-semibold text-slate-900">{f.title}</h3>
                <p className="mt-1 text-sm leading-relaxed text-slate-500">{f.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Destinations */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="flex items-end justify-between mb-8">
          <div>
            <h2 className="text-3xl font-bold tracking-tight text-slate-900">Popular Destinations</h2>
            <p className="mt-2 text-slate-500">Explore India's most loved travel spots</p>
          </div>
          <Link to="/destinations" className="inline-flex items-center gap-1 text-sm font-medium text-teal-600 hover:gap-2 transition-all">
            View All <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {destinations.map((d) => (
            <DestinationCard key={d.id} destination={d} />
          ))}
        </div>
      </section>

      {/* Featured Packages */}
      <section className="bg-slate-50 border-y border-slate-100">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
          <div className="flex items-end justify-between mb-8">
            <div>
              <h2 className="text-3xl font-bold tracking-tight text-slate-900">Featured Packages</h2>
              <p className="mt-2 text-slate-500">Handpicked tour packages for the best experiences</p>
            </div>
            <Link to="/packages" className="inline-flex items-center gap-1 text-sm font-medium text-teal-600 hover:gap-2 transition-all">
              View All <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {packages.map((p) => (
              <PackageCard key={p.id} pkg={p} />
            ))}
          </div>
        </div>
      </section>

      {/* Reviews */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold tracking-tight text-slate-900">What Our Travellers Say</h2>
          <p className="mt-2 text-slate-500">Real experiences from our happy travellers</p>
        </div>
        {reviews.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-12 text-center">
            <Star className="mx-auto h-10 w-10 text-slate-300" />
            <p className="mt-3 text-slate-500">No reviews yet. Be the first to share your experience!</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
            {reviews.map((r) => (
              <div key={r.id} className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                <StarRating rating={r.rating} />
                <p className="mt-4 text-sm leading-relaxed text-slate-600">"{r.comment}"</p>
                <div className="mt-5 flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-teal-100 text-sm font-semibold text-teal-700">
                    {(r.profile?.full_name ?? 'A')[0].toUpperCase()}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-slate-900">{r.profile?.full_name ?? 'Anonymous'}</p>
                    <p className="text-xs text-slate-400">Verified Traveller</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* CTA */}
      <section className="bg-gradient-to-br from-teal-600 to-cyan-700">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold tracking-tight text-white">Ready to Start Your Journey?</h2>
          <p className="mt-3 text-lg text-teal-100">Create your free account and book your dream trip today.</p>
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <Link to="/register">
              <Button size="lg" variant="secondary" className="bg-white text-teal-700 hover:bg-teal-50">
                Get Started Free <ArrowRight className="h-5 w-5" />
              </Button>
            </Link>
            <Link to="/packages">
              <Button size="lg" variant="outline" className="border-white/40 text-white hover:bg-white/10">
                Browse Packages
              </Button>
            </Link>
            </div>
        </div>
      </section>
    </div>
  );
}
