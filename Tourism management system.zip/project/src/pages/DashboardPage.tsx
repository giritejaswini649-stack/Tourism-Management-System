import { useEffect, useState } from 'react';
import { CalendarDays, Users, Wallet, MapPin, XCircle, CheckCircle2, Clock, Star } from 'lucide-react';
import { supabase, type BookingWithDetails, type Package } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { Link, useRouter } from '@/context/RouterContext';
import { Button } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';
import { StarRating } from '@/components/ui/StarRating';
import { useToast } from '@/context/ToastContext';
import { FullPageSpinner } from '@/components/ui/Spinner';

export function DashboardPage() {
  const { user, profile, loading: authLoading } = useAuth();
  const { navigate } = useRouter();
  const { show } = useToast();
  const [bookings, setBookings] = useState<BookingWithDetails[]>([]);
  const [loading, setLoading] = useState(true);
  const [reviewOpen, setReviewOpen] = useState<string | null>(null);
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [submittingReview, setSubmittingReview] = useState(false);
  const [reviewedIds, setReviewedIds] = useState<Set<string>>(new Set());

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/login');
      return;
    }
    if (!user) return;
    (async () => {
      const { data } = await supabase
        .from('bookings')
        .select('*, package:packages(id, title, image_url, duration_days)')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });
      setBookings(data ?? []);
      const { data: myReviews } = await supabase
        .from('reviews')
        .select('package_id')
        .eq('user_id', user.id);
      setReviewedIds(new Set((myReviews ?? []).map((r) => r.package_id)));
      setLoading(false);
    })();
  }, [user, authLoading, navigate]);

  if (authLoading || loading) return <FullPageSpinner />;

  if (profile?.role === 'admin') {
    navigate('/admin');
    return null;
  }

  const fmt = (n: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n);

  const statusInfo = (status: string) => {
    if (status === 'confirmed') return { icon: CheckCircle2, color: 'text-emerald-600', bg: 'bg-emerald-50', label: 'Confirmed' };
    if (status === 'cancelled') return { icon: XCircle, color: 'text-rose-600', bg: 'bg-rose-50', label: 'Cancelled' };
    return { icon: Clock, color: 'text-amber-600', bg: 'bg-amber-50', label: 'Pending' };
  };

  const cancelBooking = async (id: string) => {
    const { error } = await supabase.from('bookings').update({ status: 'cancelled' }).eq('id', id);
    if (error) { show('Failed to cancel booking.', 'error'); return; }
    setBookings((prev) => prev.map((b) => b.id === id ? { ...b, status: 'cancelled' } : b));
    show('Booking cancelled.', 'success');
  };

  const submitReview = async () => {
    if (!user || !reviewOpen) return;
    setSubmittingReview(true);
    const { error } = await supabase.from('reviews').insert({
      user_id: user.id,
      package_id: reviewOpen,
      rating,
      comment,
    });
    setSubmittingReview(false);
    if (error) { show('Failed to submit review.', 'error'); return; }
    setReviewedIds((prev) => new Set(prev).add(reviewOpen));
    setReviewOpen(null);
    setComment('');
    setRating(5);
    show('Review submitted! Thank you for your feedback.', 'success');
  };

  const stats = {
    total: bookings.length,
    confirmed: bookings.filter((b) => b.status === 'confirmed').length,
    pending: bookings.filter((b) => b.status === 'pending').length,
    spent: bookings.filter((b) => b.status !== 'cancelled').reduce((s, b) => s + Number(b.total_price), 0),
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight text-slate-900">My Dashboard</h1>
        <p className="mt-1 text-slate-500">Welcome back, {profile?.full_name || 'Traveller'}!</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4 mb-8">
        {[
          { label: 'Total Bookings', value: stats.total, icon: CalendarDays, color: 'text-teal-600', bg: 'bg-teal-50' },
          { label: 'Confirmed', value: stats.confirmed, icon: CheckCircle2, color: 'text-emerald-600', bg: 'bg-emerald-50' },
          { label: 'Pending', value: stats.pending, icon: Clock, color: 'text-amber-600', bg: 'bg-amber-50' },
          { label: 'Total Spent', value: fmt(stats.spent), icon: Wallet, color: 'text-slate-700', bg: 'bg-slate-100' },
        ].map((s) => (
          <div key={s.label} className="rounded-2xl border border-slate-200 bg-white p-5">
            <div className={`mb-3 flex h-10 w-10 items-center justify-center rounded-xl ${s.bg}`}>
              <s.icon className={`h-5 w-5 ${s.color}`} />
            </div>
            <p className="text-2xl font-bold text-slate-900">{s.value}</p>
            <p className="text-xs text-slate-500">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Bookings */}
      <h2 className="text-xl font-bold text-slate-900 mb-4">Your Bookings</h2>
      {bookings.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-12 text-center">
          <CalendarDays className="mx-auto h-10 w-10 text-slate-300" />
          <p className="mt-3 text-slate-500">You haven't booked any packages yet.</p>
          <Link to="/packages" className="mt-4 inline-block">
            <Button>Browse Packages</Button>
          </Link>
        </div>
      ) : (
        <div className="space-y-4">
          {bookings.map((b) => {
            const si = statusInfo(b.status);
            return (
              <div key={b.id} className="flex flex-col gap-4 rounded-2xl border border-slate-200 bg-white p-5 sm:flex-row sm:items-center">
                <img src={b.package?.image_url ?? ''} alt={b.package?.title ?? ''} className="h-24 w-full rounded-xl object-cover sm:w-32" />
                <div className="flex-1">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h3 className="font-semibold text-slate-900">{b.package?.title}</h3>
                      <p className="mt-0.5 text-sm text-slate-500">{b.package?.duration_days} days package</p>
                    </div>
                    <span className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-medium ${si.bg} ${si.color}`}>
                      <si.icon className="h-3.5 w-3.5" /> {si.label}
                    </span>
                  </div>
                  <div className="mt-3 flex flex-wrap items-center gap-4 text-sm text-slate-600">
                    <span className="inline-flex items-center gap-1.5"><CalendarDays className="h-4 w-4 text-slate-400" /> {new Date(b.travel_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
                    <span className="inline-flex items-center gap-1.5"><Users className="h-4 w-4 text-slate-400" /> {b.num_travelers} travellers</span>
                    <span className="inline-flex items-center gap-1.5"><Wallet className="h-4 w-4 text-slate-400" /> {fmt(Number(b.total_price))}</span>
                  </div>
                </div>
                <div className="flex flex-col gap-2 sm:flex-row">
                  {b.status !== 'cancelled' && !reviewedIds.has(b.package_id) && (
                    <Button variant="outline" size="sm" onClick={() => setReviewOpen(b.package_id)}>
                      <Star className="h-4 w-4" /> Review
                    </Button>
                  )}
                  {b.status === 'pending' && (
                    <Button variant="ghost" size="sm" onClick={() => cancelBooking(b.id)} className="text-rose-600 hover:bg-rose-50">
                      Cancel
                    </Button>
                  )}
                  {reviewedIds.has(b.package_id) && (
                    <span className="inline-flex items-center gap-1.5 text-xs text-emerald-600 px-3 py-2">
                      <CheckCircle2 className="h-4 w-4" /> Reviewed
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Review Modal */}
      <Modal open={!!reviewOpen} onClose={() => setReviewOpen(null)} title="Write a Review">
        <div className="space-y-5">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Your Rating</label>
            <StarRating rating={rating} interactive size={28} onChange={setRating} />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Your Review</label>
            <textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              rows={4}
              placeholder="Share your experience..."
              className="w-full rounded-xl border border-slate-300 bg-white p-3 text-sm text-slate-700 placeholder-slate-400 focus:border-teal-500 focus:outline-none focus:ring-2 focus:ring-teal-500/20 transition resize-none"
            />
          </div>
          <Button className="w-full" onClick={submitReview} disabled={submittingReview}>
            {submittingReview ? 'Submitting...' : 'Submit Review'}
          </Button>
        </div>
      </Modal>
    </div>
  );
}
