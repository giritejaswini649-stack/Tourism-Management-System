import { useEffect, useState, type ReactNode } from 'react';
import {
  MapPin, Package as PackageIcon, CalendarDays, Users as UsersIcon, Star,
  Plus, Pencil, Trash2, X, Shield, LayoutGrid,
} from 'lucide-react';
import { supabase, type Destination, type Package, type PackageWithDestination, type Booking, type Profile, type ReviewWithProfile } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from '@/context/RouterContext';
import { Button } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';
import { StarRating } from '@/components/ui/StarRating';
import { useToast } from '@/context/ToastContext';
import { FullPageSpinner } from '@/components/ui/Spinner';

type Tab = 'overview' | 'destinations' | 'packages' | 'bookings' | 'users' | 'reviews';

export function AdminPage() {
  const { user, profile, loading: authLoading } = useAuth();
  const { navigate } = useRouter();
  const { show } = useToast();
  const [tab, setTab] = useState<Tab>('overview');
  const [loading, setLoading] = useState(true);

  const [destinations, setDestinations] = useState<Destination[]>([]);
  const [packages, setPackages] = useState<PackageWithDestination[]>([]);
  const [bookings, setBookings] = useState<(Booking & { profile: Pick<Profile, 'id' | 'full_name'> | null; package: Pick<Package, 'id' | 'title'> | null })[]>([]);
  const [users, setUsers] = useState<Profile[]>([]);
  const [reviews, setReviews] = useState<ReviewWithProfile[]>([]);

  // Modal state
  const [destModalOpen, setDestModalOpen] = useState(false);
  const [editingDest, setEditingDest] = useState<Destination | null>(null);
  const [pkgModalOpen, setPkgModalOpen] = useState(false);
  const [editingPkg, setEditingPkg] = useState<Package | null>(null);

  useEffect(() => {
    if (!authLoading && (!user || profile?.role !== 'admin')) {
      navigate('/login');
      return;
    }
    if (!user) return;
    loadAll();
  }, [user, authLoading, profile, navigate]);

  const loadAll = async () => {
    setLoading(true);
    const [d, p, b, u, r] = await Promise.all([
      supabase.from('destinations').select('*').order('created_at', { ascending: false }),
      supabase.from('packages').select('*, destination:destinations(id, name, location, region)').order('created_at', { ascending: false }),
      supabase.from('bookings').select('*, profile:profiles(id, full_name), package:packages(id, title)').order('created_at', { ascending: false }),
      supabase.from('profiles').select('*').order('created_at', { ascending: false }),
      supabase.from('reviews').select('*, profile:profiles(id, full_name)').order('created_at', { ascending: false }),
    ]);
    setDestinations(d.data ?? []);
    setPackages(p.data ?? []);
    setBookings(b.data ?? []);
    setUsers(u.data ?? []);
    setReviews(r.data ?? []);
    setLoading(false);
  };

  if (authLoading || loading) return <FullPageSpinner />;
  if (profile?.role !== 'admin') return null;

  const fmt = (n: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n);

  // === Destinations CRUD ===
  const saveDestination = async (data: Partial<Destination>) => {
    if (editingDest) {
      const { error } = await supabase.from('destinations').update(data).eq('id', editingDest.id);
      if (error) { show(error.message, 'error'); return; }
      show('Destination updated.', 'success');
    } else {
      const { error } = await supabase.from('destinations').insert(data);
      if (error) { show(error.message, 'error'); return; }
      show('Destination added.', 'success');
    }
    setDestModalOpen(false);
    setEditingDest(null);
    loadAll();
  };

  const deleteDestination = async (id: string) => {
    if (!confirm('Delete this destination and all its packages?')) return;
    const { error } = await supabase.from('destinations').delete().eq('id', id);
    if (error) { show(error.message, 'error'); return; }
    show('Destination deleted.', 'success');
    loadAll();
  };

  // === Packages CRUD ===
  const savePackage = async (data: Partial<Package>) => {
    if (editingPkg) {
      const { error } = await supabase.from('packages').update(data).eq('id', editingPkg.id);
      if (error) { show(error.message, 'error'); return; }
      show('Package updated.', 'success');
    } else {
      const { error } = await supabase.from('packages').insert(data);
      if (error) { show(error.message, 'error'); return; }
      show('Package added.', 'success');
    }
    setPkgModalOpen(false);
    setEditingPkg(null);
    loadAll();
  };

  const deletePackage = async (id: string) => {
    if (!confirm('Delete this package?')) return;
    const { error } = await supabase.from('packages').delete().eq('id', id);
    if (error) { show(error.message, 'error'); return; }
    show('Package deleted.', 'success');
    loadAll();
  };

  // === Booking status ===
  const updateBookingStatus = async (id: string, status: string) => {
    const { error } = await supabase.from('bookings').update({ status }).eq('id', id);
    if (error) { show(error.message, 'error'); return; }
    show(`Booking marked as ${status}.`, 'success');
    loadAll();
  };

  // === User role ===
  const updateUserRole = async (id: string, role: string) => {
    const { error } = await supabase.from('profiles').update({ role }).eq('id', id);
    if (error) { show(error.message, 'error'); return; }
    show('User role updated.', 'success');
    loadAll();
  };

  // === Delete review ===
  const deleteReview = async (id: string) => {
    if (!confirm('Delete this review?')) return;
    const { error } = await supabase.from('reviews').delete().eq('id', id);
    if (error) { show(error.message, 'error'); return; }
    show('Review deleted.', 'success');
    loadAll();
  };

  const tabs: { id: Tab; label: string; icon: typeof MapPin }[] = [
    { id: 'overview', label: 'Overview', icon: LayoutGrid },
    { id: 'destinations', label: 'Destinations', icon: MapPin },
    { id: 'packages', label: 'Packages', icon: PackageIcon },
    { id: 'bookings', label: 'Bookings', icon: CalendarDays },
    { id: 'users', label: 'Users', icon: UsersIcon },
    { id: 'reviews', label: 'Reviews', icon: Star },
  ];

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <div className="mb-8 flex items-center gap-3">
        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-slate-900">
          <Shield className="h-6 w-6 text-white" />
        </div>
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-slate-900">Admin Panel</h1>
          <p className="text-sm text-slate-500">Manage destinations, packages, bookings, users, and reviews</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="mb-8 flex flex-wrap gap-2 border-b border-slate-200">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`inline-flex items-center gap-2 border-b-2 px-4 py-2.5 text-sm font-medium transition ${
              tab === t.id
                ? 'border-teal-600 text-teal-600'
                : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}
          >
            <t.icon className="h-4 w-4" /> {t.label}
          </button>
        ))}
      </div>

      {/* Overview */}
      {tab === 'overview' && (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
          {[
            { label: 'Destinations', value: destinations.length, icon: MapPin, color: 'text-teal-600', bg: 'bg-teal-50' },
            { label: 'Packages', value: packages.length, icon: PackageIcon, color: 'text-cyan-600', bg: 'bg-cyan-50' },
            { label: 'Bookings', value: bookings.length, icon: CalendarDays, color: 'text-amber-600', bg: 'bg-amber-50' },
            { label: 'Users', value: users.length, icon: UsersIcon, color: 'text-slate-700', bg: 'bg-slate-100' },
            { label: 'Reviews', value: reviews.length, icon: Star, color: 'text-violet-600', bg: 'bg-violet-50' },
          ].map((s) => (
            <div key={s.label} className="rounded-2xl border border-slate-200 bg-white p-5">
              <div className={`mb-3 flex h-10 w-10 items-center justify-center rounded-xl ${s.bg}`}>
                <s.icon className={`h-5 w-5 ${s.color}`} />
              </div>
              <p className="text-2xl font-bold text-slate-900">{s.value}</p>
              <p className="text-xs text-slate-500">{s.label}</p>
            </div>
          ))}
        </div>
      )}

      {/* Destinations */}
      {tab === 'destinations' && (
        <div>
          <div className="mb-4 flex justify-end">
            <Button onClick={() => { setEditingDest(null); setDestModalOpen(true); }}>
              <Plus className="h-4 w-4" /> Add Destination
            </Button>
          </div>
          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-xs uppercase text-slate-500">
                <tr>
                  <th className="px-4 py-3 font-medium">Name</th>
                  <th className="px-4 py-3 font-medium">Location</th>
                  <th className="px-4 py-3 font-medium">Region</th>
                  <th className="px-4 py-3 font-medium">Attractions</th>
                  <th className="px-4 py-3 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {destinations.map((d) => (
                  <tr key={d.id} className="hover:bg-slate-50">
                    <td className="px-4 py-3 font-medium text-slate-900">{d.name}</td>
                    <td className="px-4 py-3 text-slate-600">{d.location}</td>
                    <td className="px-4 py-3 text-slate-600">{d.region}</td>
                    <td className="px-4 py-3 text-slate-500">{d.attractions.length} items</td>
                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-2">
                        <button onClick={() => { setEditingDest(d); setDestModalOpen(true); }} className="rounded-lg p-2 text-slate-500 hover:bg-teal-50 hover:text-teal-600 transition">
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button onClick={() => deleteDestination(d.id)} className="rounded-lg p-2 text-slate-500 hover:bg-rose-50 hover:text-rose-600 transition">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Packages */}
      {tab === 'packages' && (
        <div>
          <div className="mb-4 flex justify-end">
            <Button onClick={() => { setEditingPkg(null); setPkgModalOpen(true); }}>
              <Plus className="h-4 w-4" /> Add Package
            </Button>
          </div>
          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-xs uppercase text-slate-500">
                <tr>
                  <th className="px-4 py-3 font-medium">Title</th>
                  <th className="px-4 py-3 font-medium">Destination</th>
                  <th className="px-4 py-3 font-medium">Duration</th>
                  <th className="px-4 py-3 font-medium">Price</th>
                  <th className="px-4 py-3 font-medium">Featured</th>
                  <th className="px-4 py-3 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {packages.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50">
                    <td className="px-4 py-3 font-medium text-slate-900">{p.title}</td>
                    <td className="px-4 py-3 text-slate-600">{p.destination?.name ?? '—'}</td>
                    <td className="px-4 py-3 text-slate-600">{p.duration_days} days</td>
                    <td className="px-4 py-3 text-slate-600">{fmt(p.price)}</td>
                    <td className="px-4 py-3">
                      {p.featured ? (
                        <span className="rounded-full bg-amber-50 px-2.5 py-0.5 text-xs font-medium text-amber-700">Yes</span>
                      ) : (
                        <span className="text-xs text-slate-400">No</span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-2">
                        <button onClick={() => { setEditingPkg(p); setPkgModalOpen(true); }} className="rounded-lg p-2 text-slate-500 hover:bg-teal-50 hover:text-teal-600 transition">
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button onClick={() => deletePackage(p.id)} className="rounded-lg p-2 text-slate-500 hover:bg-rose-50 hover:text-rose-600 transition">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Bookings */}
      {tab === 'bookings' && (
        <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 text-xs uppercase text-slate-500">
              <tr>
                <th className="px-4 py-3 font-medium">Customer</th>
                <th className="px-4 py-3 font-medium">Package</th>
                <th className="px-4 py-3 font-medium">Travel Date</th>
                <th className="px-4 py-3 font-medium">Travellers</th>
                <th className="px-4 py-3 font-medium">Total</th>
                <th className="px-4 py-3 font-medium">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {bookings.length === 0 ? (
                <tr><td colSpan={6} className="px-4 py-8 text-center text-slate-500">No bookings yet.</td></tr>
              ) : bookings.map((b) => (
                <tr key={b.id} className="hover:bg-slate-50">
                  <td className="px-4 py-3 font-medium text-slate-900">{b.profile?.full_name ?? '—'}</td>
                  <td className="px-4 py-3 text-slate-600">{b.package?.title ?? '—'}</td>
                  <td className="px-4 py-3 text-slate-600">{new Date(b.travel_date).toLocaleDateString('en-IN')}</td>
                  <td className="px-4 py-3 text-slate-600">{b.num_travelers}</td>
                  <td className="px-4 py-3 text-slate-600">{fmt(Number(b.total_price))}</td>
                  <td className="px-4 py-3">
                    <select
                      value={b.status}
                      onChange={(e) => updateBookingStatus(b.id, e.target.value)}
                      className="rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs text-slate-700 focus:border-teal-500 focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                    >
                      <option value="pending">Pending</option>
                      <option value="confirmed">Confirmed</option>
                      <option value="cancelled">Cancelled</option>
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Users */}
      {tab === 'users' && (
        <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 text-xs uppercase text-slate-500">
              <tr>
                <th className="px-4 py-3 font-medium">Name</th>
                <th className="px-4 py-3 font-medium">Joined</th>
                <th className="px-4 py-3 font-medium">Role</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {users.map((u) => (
                <tr key={u.id} className="hover:bg-slate-50">
                  <td className="px-4 py-3 font-medium text-slate-900">{u.full_name || '(no name)'}</td>
                  <td className="px-4 py-3 text-slate-600">{new Date(u.created_at).toLocaleDateString('en-IN')}</td>
                  <td className="px-4 py-3">
                    <select
                      value={u.role}
                      onChange={(e) => updateUserRole(u.id, e.target.value)}
                      disabled={u.id === user?.id}
                      className="rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs text-slate-700 focus:border-teal-500 focus:outline-none focus:ring-2 focus:ring-teal-500/20 disabled:opacity-50"
                    >
                      <option value="user">User</option>
                      <option value="admin">Admin</option>
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Reviews */}
      {tab === 'reviews' && (
        <div className="space-y-4">
          {reviews.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-12 text-center">
              <Star className="mx-auto h-8 w-8 text-slate-300" />
              <p className="mt-2 text-slate-500">No reviews yet.</p>
            </div>
          ) : reviews.map((r) => (
            <div key={r.id} className="flex items-start justify-between gap-4 rounded-2xl border border-slate-200 bg-white p-5">
              <div className="flex-1">
                <div className="flex items-center gap-3">
                  <div className="flex h-9 w-9 items-center justify-center rounded-full bg-teal-100 text-sm font-semibold text-teal-700">
                    {(r.profile?.full_name ?? 'A')[0].toUpperCase()}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-slate-900">{r.profile?.full_name ?? 'Anonymous'}</p>
                    <StarRating rating={r.rating} size={14} />
                  </div>
                </div>
                <p className="mt-3 text-sm leading-relaxed text-slate-600">{r.comment}</p>
              </div>
              <button onClick={() => deleteReview(r.id)} className="rounded-lg p-2 text-slate-400 hover:bg-rose-50 hover:text-rose-600 transition">
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Destination Modal */}
      {destModalOpen && (
        <DestinationFormModal
          destination={editingDest}
          onClose={() => { setDestModalOpen(false); setEditingDest(null); }}
          onSave={saveDestination}
        />
      )}

      {/* Package Modal */}
      {pkgModalOpen && (
        <PackageFormModal
          pkg={editingPkg}
          destinations={destinations}
          onClose={() => { setPkgModalOpen(false); setEditingPkg(null); }}
          onSave={savePackage}
        />
      )}
    </div>
  );
}

// === Destination Form Modal ===
function DestinationFormModal({
  destination,
  onClose,
  onSave,
}: {
  destination: Destination | null;
  onClose: () => void;
  onSave: (data: Partial<Destination>) => void;
}) {
  const [name, setName] = useState(destination?.name ?? '');
  const [location, setLocation] = useState(destination?.location ?? '');
  const [region, setRegion] = useState(destination?.region ?? '');
  const [description, setDescription] = useState(destination?.description ?? '');
  const [attractions, setAttractions] = useState((destination?.attractions ?? []).join('\n'));
  const [imageUrl, setImageUrl] = useState(destination?.image_url ?? '');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      name,
      location,
      region,
      description,
      attractions: attractions.split('\n').map((s) => s.trim()).filter(Boolean),
      image_url: imageUrl,
    });
  };

  return (
    <Modal open onClose={onClose} title={destination ? 'Edit Destination' : 'Add Destination'} size="lg">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Field label="Name">
            <input required value={name} onChange={(e) => setName(e.target.value)} className={inputClass} />
          </Field>
          <Field label="Location">
            <input required value={location} onChange={(e) => setLocation(e.target.value)} className={inputClass} />
          </Field>
        </div>
        <Field label="Region">
          <input value={region} onChange={(e) => setRegion(e.target.value)} className={inputClass} />
        </Field>
        <Field label="Description">
          <textarea required value={description} onChange={(e) => setDescription(e.target.value)} rows={3} className={`${inputClass} resize-none`} />
        </Field>
        <Field label="Attractions (one per line)">
          <textarea value={attractions} onChange={(e) => setAttractions(e.target.value)} rows={4} className={`${inputClass} resize-none`} placeholder="Beach&#10;Fort&#10;Market" />
        </Field>
        <Field label="Image URL">
          <input value={imageUrl} onChange={(e) => setImageUrl(e.target.value)} className={inputClass} placeholder="https://..." />
        </Field>
        <div className="flex justify-end gap-3 pt-2">
          <Button type="button" variant="ghost" onClick={onClose}>Cancel</Button>
          <Button type="submit">{destination ? 'Update' : 'Add Destination'}</Button>
        </div>
      </form>
    </Modal>
  );
}

// === Package Form Modal ===
function PackageFormModal({
  pkg,
  destinations,
  onClose,
  onSave,
}: {
  pkg: Package | null;
  destinations: Destination[];
  onClose: () => void;
  onSave: (data: Partial<Package>) => void;
}) {
  const [title, setTitle] = useState(pkg?.title ?? '');
  const [destinationId, setDestinationId] = useState(pkg?.destination_id ?? destinations[0]?.id ?? '');
  const [description, setDescription] = useState(pkg?.description ?? '');
  const [duration, setDuration] = useState(pkg?.duration_days ?? 3);
  const [price, setPrice] = useState(pkg?.price ?? 10000);
  const [activities, setActivities] = useState((pkg?.activities ?? []).join('\n'));
  const [inclusions, setInclusions] = useState((pkg?.inclusions ?? []).join('\n'));
  const [imageUrl, setImageUrl] = useState(pkg?.image_url ?? '');
  const [featured, setFeatured] = useState(pkg?.featured ?? false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      title,
      destination_id: destinationId,
      description,
      duration_days: Number(duration),
      price: Number(price),
      activities: activities.split('\n').map((s) => s.trim()).filter(Boolean),
      inclusions: inclusions.split('\n').map((s) => s.trim()).filter(Boolean),
      image_url: imageUrl,
      featured,
    });
  };

  return (
    <Modal open onClose={onClose} title={pkg ? 'Edit Package' : 'Add Package'} size="lg">
      <form onSubmit={handleSubmit} className="space-y-4">
        <Field label="Title">
          <input required value={title} onChange={(e) => setTitle(e.target.value)} className={inputClass} />
        </Field>
        <Field label="Destination">
          <select required value={destinationId} onChange={(e) => setDestinationId(e.target.value)} className={inputClass}>
            <option value="">Select destination...</option>
            {destinations.map((d) => (
              <option key={d.id} value={d.id}>{d.name}</option>
            ))}
          </select>
        </Field>
        <Field label="Description">
          <textarea required value={description} onChange={(e) => setDescription(e.target.value)} rows={3} className={`${inputClass} resize-none`} />
        </Field>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Field label="Duration (days)">
            <input type="number" min={1} required value={duration} onChange={(e) => setDuration(Number(e.target.value))} className={inputClass} />
          </Field>
          <Field label="Price (INR)">
            <input type="number" min={0} required value={price} onChange={(e) => setPrice(Number(e.target.value))} className={inputClass} />
          </Field>
        </div>
        <Field label="Activities (one per line)">
          <textarea value={activities} onChange={(e) => setActivities(e.target.value)} rows={3} className={`${inputClass} resize-none`} />
        </Field>
        <Field label="Inclusions (one per line)">
          <textarea value={inclusions} onChange={(e) => setInclusions(e.target.value)} rows={3} className={`${inputClass} resize-none`} />
        </Field>
        <Field label="Image URL">
          <input value={imageUrl} onChange={(e) => setImageUrl(e.target.value)} className={inputClass} placeholder="https://..." />
        </Field>
        <label className="flex items-center gap-2.5 cursor-pointer">
          <input type="checkbox" checked={featured} onChange={(e) => setFeatured(e.target.checked)} className="h-4 w-4 rounded border-slate-300 text-teal-600 focus:ring-teal-500" />
          <span className="text-sm text-slate-700">Featured package</span>
        </label>
        <div className="flex justify-end gap-3 pt-2">
          <Button type="button" variant="ghost" onClick={onClose}>Cancel</Button>
          <Button type="submit">{pkg ? 'Update' : 'Add Package'}</Button>
        </div>
      </form>
    </Modal>
  );
}

const inputClass = 'w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-700 placeholder-slate-400 focus:border-teal-500 focus:outline-none focus:ring-2 focus:ring-teal-500/20 transition';

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div>
      <label className="block text-sm font-medium text-slate-700 mb-1.5">{label}</label>
      {children}
    </div>
  );
}
