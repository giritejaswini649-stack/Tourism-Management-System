import { useEffect, useState } from 'react';
import { MapPin, CheckCircle, ArrowRight } from 'lucide-react';
import { supabase, type Destination, type PackageWithDestination } from '@/lib/supabase';
import { Link } from '@/context/RouterContext';
import { PackageCard } from '@/components/PackageCard';
import { FullPageSpinner } from '@/components/ui/Spinner';

export function DestinationDetailPage({ id }: { id: string }) {
  const [destination, setDestination] = useState<Destination | null>(null);
  const [packages, setPackages] = useState<PackageWithDestination[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const [{ data: dest }, { data: pkgs }] = await Promise.all([
        supabase.from('destinations').select('*').eq('id', id).maybeSingle(),
        supabase
          .from('packages')
          .select('*, destination:destinations(id, name, location, region)')
          .eq('destination_id', id),
      ]);
      setDestination(dest as Destination | null);
      setPackages(pkgs ?? []);
      setLoading(false);
    })();
  }, [id]);

  if (loading) return <FullPageSpinner />;

  if (!destination) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-20 text-center">
        <h1 className="text-2xl font-bold text-slate-900">Destination not found</h1>
        <Link to="/destinations" className="mt-4 inline-block text-teal-600 hover:underline">
          Back to destinations
        </Link>
      </div>
    );
  }

  return (
    <div>
      {/* Hero */}
      <div className="relative h-[40vh] min-h-[300px] overflow-hidden">
        <img src={destination.image_url} alt={destination.name} className="h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900/90 via-slate-900/50 to-slate-900/20" />
        <div className="absolute bottom-0 left-0 right-0 mx-auto max-w-7xl px-4 pb-8 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2 text-teal-300 text-sm font-medium mb-2">
            <MapPin className="h-4 w-4" /> {destination.location}
          </div>
          <h1 className="text-4xl font-bold tracking-tight text-white sm:text-5xl">{destination.name}</h1>
          <span className="mt-2 inline-block rounded-full bg-white/15 px-3 py-1 text-xs font-medium text-white backdrop-blur-sm">
            {destination.region}
          </span>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        {/* Description */}
        <div className="grid grid-cols-1 gap-10 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <h2 className="text-2xl font-bold text-slate-900">About {destination.name}</h2>
            <p className="mt-4 text-base leading-relaxed text-slate-600">{destination.description}</p>
          </div>
          <div className="rounded-2xl border border-slate-200 bg-slate-50 p-6">
            <h3 className="font-semibold text-slate-900">Top Attractions</h3>
            <ul className="mt-4 space-y-3">
              {destination.attractions.map((a) => (
                <li key={a} className="flex items-start gap-2.5 text-sm text-slate-600">
                  <CheckCircle className="h-5 w-5 shrink-0 text-teal-500" />
                  {a}
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Packages */}
        <div className="mt-14">
          <div className="flex items-end justify-between mb-6">
            <div>
              <h2 className="text-2xl font-bold text-slate-900">Tour Packages in {destination.name}</h2>
              <p className="mt-1 text-slate-500">{packages.length} package(s) available</p>
            </div>
            <Link to="/packages" className="inline-flex items-center gap-1 text-sm font-medium text-teal-600 hover:gap-2 transition-all">
              All Packages <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          {packages.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-12 text-center">
              <p className="text-slate-500">No packages available for this destination yet. Check back soon!</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {packages.map((p) => (
                <PackageCard key={p.id} pkg={p} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
